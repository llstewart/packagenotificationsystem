# Netflix-Style Portfolio Application

## Overview

This project is a Netflix-inspired portfolio application that mimics the Netflix UI for showcasing a developer's portfolio. The application features profile selection, content sections by category, and a responsive design. It uses a React frontend with a Node.js/Express backend, Drizzle ORM for database interactions, and shadcn/ui components for the UI.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack architecture with clear separation between client and server:

1. **Frontend**: React application with Vite bundler, using shadcn/ui components
2. **Backend**: Express.js server for API endpoints
3. **Database**: PostgreSQL database using Drizzle ORM for schema definitions and queries
4. **Styling**: Tailwind CSS with a Netflix-inspired design system

The application is organized into:
- `client/`: React application
- `server/`: Express server
- `shared/`: Database schema and shared types
- Various configuration files for Drizzle, Vite, and Tailwind

## Key Components

### Frontend Architecture

The frontend is built with React and organized as follows:

1. **Pages**: 
   - `Home.tsx`: Main entry point showing loading screen, profile selection, and content
   - `not-found.tsx`: 404 page

2. **Components**:
   - UI components: Using shadcn/ui component library
   - Custom components:
     - `LoadingScreen.tsx`: Initial loading animation
     - `ProfileSelection.tsx`: Netflix-style profile selection
     - `ContentScreen.tsx`: Main content display area
     - `ContentCard.tsx`: Cards for displaying portfolio items
     - `NetflixLogo.tsx`: Custom Netflix-style logo

3. **State Management**:
   - Local component state
   - React Query for API data fetching

4. **Styling**:
   - Tailwind CSS with custom Netflix-inspired theme
   - CSS animations for transitions
   - Responsive design for different screen sizes

### Backend Architecture

The backend is a Node.js/Express server:

1. **API Routes**: 
   - `/api/profiles`: Get user profiles
   - `/api/content`: Get content items, optionally filtered by section
   - `/api/profiles/:id/image`: Update profile image
   - `/api/content/:id/image`: Update content item image

2. **Data Storage**: 
   - PostgreSQL database accessed through Drizzle ORM
   - Schema defined in `shared/schema.ts`
   - Memory storage implementation for development

3. **Server Setup**:
   - Express middleware for request logging and error handling
   - Development mode with Vite integration
   - Static file serving for production build

### Database Schema

The database schema consists of three main tables:

1. **Users**: 
   - Authentication credentials for admin access

2. **Profiles**:
   - Represents Netflix-style selection profiles
   - Each profile has a name, image, and section association

3. **ContentItems**:
   - Portfolio items organized by section
   - Contains title, description, image URL, and section

## Data Flow

1. **User Interaction Flow**:
   - User visits site → Loading screen appears
   - After loading → Profile selection screen shows
   - User selects profile → Content screen loads with filtered content
   - Content is categorized by section (about, projects, skills, contact)

2. **API Data Flow**:
   - Frontend requests data from API endpoints
   - Backend retrieves data from database (using Drizzle ORM)
   - Data is returned as JSON responses
   - React components render based on retrieved data

3. **Authentication**:
   - Basic user/password authentication schema exists in the database
   - Not fully implemented in current version

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React with shadcn/ui components
- **Styling**: Tailwind CSS
- **Animation**: Framer Motion for transitions
- **State Management**: React Query
- **Routing**: Wouter (lightweight alternative to React Router)
- **Form Handling**: React Hook Form with Zod validation

### Backend Dependencies
- **Server**: Express.js
- **Database ORM**: Drizzle ORM
- **Database Client**: @neondatabase/serverless (for PostgreSQL)
- **Development**: Vite for dev server and HMR

### Development Tools
- **TypeScript**: For type safety
- **ESBuild**: For server code bundling
- **PostCSS**: For CSS processing

## Deployment Strategy

The application is configured for deployment on Replit with:

1. **Build Process**:
   - `npm run build`: Bundles both client and server
   - Vite builds the frontend into static files
   - ESBuild bundles the server code

2. **Runtime Configuration**:
   - `npm run start`: Runs the production server
   - Environment variables for configuration
   - Database connection string required via `DATABASE_URL`

3. **Replit-Specific Configuration**:
   - `.replit` file configures build and run commands
   - Node.js 20, PostgreSQL 16, and web modules enabled
   - Deployment target set to "autoscale"
   - Port 5000 exposed and mapped to external port 80

4. **Database Provisioning**:
   - Drizzle configuration to use PostgreSQL
   - Run `npm run db:push` to synchronize schema changes

For local development, run `npm run dev` which starts the Express server with Vite's development middleware for the React application.