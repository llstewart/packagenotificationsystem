import { useState, useEffect } from "react";
import LoadingScreen from "@/components/LoadingScreen";
import ProfileSelection from "@/components/ProfileSelection";
import ContentScreen from "@/components/ContentScreen";
import { Profile } from "@/lib/types";
import { PLACEHOLDER_PROFILES, CONTENT_SECTIONS } from "@/lib/constants";
import { Helmet } from "react-helmet";
import { apiRequest } from "@/lib/queryClient";

const Home = () => {
  const [loading, setLoading] = useState(true);
  const [showProfileSelection, setShowProfileSelection] = useState(false);
  const [showContentScreen, setShowContentScreen] = useState(false);
  const [activeSection, setActiveSection] = useState<string | undefined>(undefined);

  const handleLoadingComplete = () => {
    setLoading(false);
    setShowProfileSelection(true);
  };

  const handleProfileSelect = (profile: Profile) => {
    setShowProfileSelection(false);
    setActiveSection(profile.section);
    setTimeout(() => {
      setShowContentScreen(true);
    }, 500);
  };

  return (
    <>
      <Helmet>
        <title>Netflix-Style Portfolio | Choose Your Profile</title>
        <meta name="description" content="An interactive Netflix-themed portfolio showcasing projects, skills, and professional experience in a unique and engaging way." />
        <meta property="og:title" content="Netflix-Style Portfolio" />
        <meta property="og:description" content="Explore my work through this Netflix-inspired portfolio showcase." />
        <meta property="og:type" content="website" />
      </Helmet>

      {loading && <LoadingScreen onLoadingComplete={handleLoadingComplete} />}
      
      <ProfileSelection 
        profiles={PLACEHOLDER_PROFILES} 
        onProfileSelect={handleProfileSelect}
        visible={showProfileSelection}
      />
      
      <ContentScreen 
        contentSections={CONTENT_SECTIONS}
        activeSection={activeSection}
        visible={showContentScreen}
      />
    </>
  );
};

export default Home;
