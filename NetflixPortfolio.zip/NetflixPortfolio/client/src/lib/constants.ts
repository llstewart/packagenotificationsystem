export const PLACEHOLDER_PROFILES = [
  {
    id: 1,
    name: "About Me",
    image: "https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
    section: "about",
  },
  {
    id: 2,
    name: "Projects",
    image: "https://images.unsplash.com/photo-1522252234503-e356532cafd5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
    section: "projects",
  },
  {
    id: 3,
    name: "Skills",
    image: "https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
    section: "skills",
  },
  {
    id: 4,
    name: "Contact",
    image: "https://images.unsplash.com/photo-1543269664-76bc3997d9ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
    section: "contact",
  },
];

export const HERO_BACKGROUND = "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080&q=80";

export const CONTENT_SECTIONS = {
  about: [
    {
      id: 1,
      title: "Work Experience",
      description: "My professional journey",
      image: "https://images.unsplash.com/photo-1516110833967-0b5716ca1387?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
    },
    {
      id: 2,
      title: "Education",
      description: "My academic background",
      image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
    },
  ],
  projects: [
    {
      id: 3,
      title: "Web Development",
      description: "Frontend & backend projects",
      image: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
    },
    {
      id: 4,
      title: "Mobile Apps",
      description: "iOS & Android development",
      image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
    },
    {
      id: 5,
      title: "Design Work",
      description: "UI/UX and graphic design",
      image: "https://images.unsplash.com/photo-1558655146-364adaf1fcc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
    },
  ],
  skills: [
    {
      id: 6,
      title: "Technical Skills",
      description: "Programming languages & tools",
      image: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
    },
  ],
};
