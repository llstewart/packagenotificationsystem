export interface Profile {
  id: number;
  name: string;
  image: string;
  section: string;
}

export interface ContentItem {
  id: number;
  title: string;
  description: string;
  image: string;
}

export interface ContentSections {
  about: ContentItem[];
  projects: ContentItem[];
  skills: ContentItem[];
  [key: string]: ContentItem[];
}
