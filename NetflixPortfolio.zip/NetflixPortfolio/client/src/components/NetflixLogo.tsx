const NetflixLogo = ({ className = "" }: { className?: string }) => {
  return (
    <h1 className={`text-netflix-red font-bebas tracking-wide ${className}`}>PORTFOLIO</h1>
  );
};

export default NetflixLogo;
