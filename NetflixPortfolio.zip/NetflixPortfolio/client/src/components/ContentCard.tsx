import { motion } from "framer-motion";
import { ContentItem } from "@/lib/types";

interface ContentCardProps {
  item: ContentItem;
}

const ContentCard = ({ item }: ContentCardProps) => {
  return (
    <motion.div
      className="content-card relative aspect-video rounded overflow-hidden"
      whileHover={{ scale: 1.1, zIndex: 10 }}
    >
      <img 
        src={item.image} 
        alt={`${item.title} thumbnail`} 
        className="w-full h-full object-cover"
      />
      <div className="content-info absolute inset-0 bg-gradient-to-t from-black/90 to-transparent p-4 flex flex-col justify-end opacity-0 transition-opacity">
        <h3 className="text-lg font-medium">{item.title}</h3>
        <p className="text-sm text-gray-300">{item.description}</p>
      </div>
    </motion.div>
  );
};

export default ContentCard;
