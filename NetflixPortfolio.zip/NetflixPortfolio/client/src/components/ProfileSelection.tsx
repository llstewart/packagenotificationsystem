import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Profile } from "@/lib/types";
import { Button } from "@/components/ui/button";

interface ProfileSelectionProps {
  profiles: Profile[];
  onProfileSelect: (profile: Profile) => void;
  visible: boolean;
}

const ProfileSelection = ({ profiles, onProfileSelect, visible }: ProfileSelectionProps) => {
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);

  const handleProfileClick = (profile: Profile) => {
    setSelectedProfile(profile);
    setTimeout(() => {
      onProfileSelect(profile);
    }, 300);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        duration: 0.5,
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    },
    exit: { 
      opacity: 0,
      transition: { duration: 0.5 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
    exit: { y: -20, opacity: 0 }
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="min-h-screen flex flex-col items-center justify-center py-10 px-4"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <div className="fixed inset-0 bg-gradient-to-b from-netflix-black via-netflix-black to-netflix-dark z-[-1]"></div>
          
          <motion.h1 
            className="text-4xl md:text-5xl font-bebas mb-8 text-white"
            variants={itemVariants}
          >
            Who's viewing?
          </motion.h1>
          
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8 max-w-4xl"
            variants={itemVariants}
          >
            {profiles.map((profile) => (
              <motion.div
                key={profile.id}
                className="flex flex-col items-center"
                variants={itemVariants}
                whileHover={{ scale: 1.05 }}
                onClick={() => handleProfileClick(profile)}
              >
                <div 
                  className="profile-image w-28 h-28 md:w-36 md:h-36 rounded bg-netflix-gray mb-3" 
                  style={{ backgroundImage: `url('${profile.image}')` }}
                />
                <span className="text-netflix-lightgray font-medium">{profile.name}</span>
              </motion.div>
            ))}
          </motion.div>
          
          <motion.div className="mt-12" variants={itemVariants}>
            <Button
              variant="outline"
              className="px-6 py-2 border border-netflix-lightgray text-netflix-lightgray hover:border-white hover:text-white transition-colors"
            >
              Add Profile
            </Button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ProfileSelection;
