import { useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ContentSections } from "@/lib/types";
import ContentCard from "./ContentCard";
import NetflixLogo from "./NetflixLogo";
import { Button } from "@/components/ui/button";
import { Play, Info } from "lucide-react";
import { HERO_BACKGROUND } from "@/lib/constants";

interface ContentScreenProps {
  contentSections: ContentSections;
  activeSection?: string;
  visible: boolean;
}

const ContentScreen = ({ contentSections, activeSection, visible }: ContentScreenProps) => {
  const aboutRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLElement>(null);
  const skillsRef = useRef<HTMLElement>(null);
  const contactRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (visible && activeSection) {
      const sectionRefs: { [key: string]: React.RefObject<HTMLElement> } = {
        about: aboutRef,
        projects: projectsRef,
        skills: skillsRef,
        contact: contactRef
      };
      
      const ref = sectionRefs[activeSection];
      if (ref.current) {
        setTimeout(() => {
          ref.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    }
  }, [visible, activeSection]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5 } },
    exit: { opacity: 0, transition: { duration: 0.5 } }
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="min-h-screen"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <header className="fixed top-0 w-full bg-gradient-to-b from-netflix-black to-transparent px-4 py-4 z-40">
            <div className="container mx-auto flex justify-between items-center">
              <NetflixLogo className="text-3xl md:text-4xl" />
              <nav>
                <ul className="flex space-x-6">
                  <li><a href="#about-section" className="hover:text-netflix-red">About</a></li>
                  <li><a href="#projects-section" className="hover:text-netflix-red">Projects</a></li>
                  <li><a href="#skills-section" className="hover:text-netflix-red">Skills</a></li>
                  <li><a href="#contact-section" className="hover:text-netflix-red">Contact</a></li>
                </ul>
              </nav>
            </div>
          </header>

          <div className="relative h-[70vh] w-full overflow-hidden">
            <div 
              className="absolute inset-0 bg-netflix-black" 
              style={{ 
                backgroundImage: `url('${HERO_BACKGROUND}')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            ></div>
            
            <div className="absolute inset-0 bg-gradient-to-t from-netflix-black via-netflix-black/60 to-netflix-black/10"></div>
            
            <div className="absolute bottom-0 left-0 p-8 md:p-16 w-full">
              <h2 className="text-4xl md:text-6xl font-bebas mb-4">My Portfolio</h2>
              <p className="text-lg md:text-xl max-w-2xl mb-6">
                Explore my work through this Netflix-inspired portfolio showcase. 
                Click on any section to learn more about me and my projects.
              </p>
              <div className="flex space-x-4">
                <Button 
                  className="bg-netflix-red hover:bg-netflix-darkred text-white px-6 py-2 flex items-center transition-colors"
                >
                  <Play className="mr-2 h-4 w-4" /> Featured Project
                </Button>
                <Button 
                  variant="secondary"
                  className="bg-netflix-gray/60 hover:bg-netflix-gray text-white px-6 py-2 flex items-center transition-colors"
                >
                  <Info className="mr-2 h-4 w-4" /> More Info
                </Button>
              </div>
            </div>
          </div>

          <main className="px-4 md:px-8 pb-16 bg-netflix-black">
            <section id="about-section" ref={aboutRef} className="py-8">
              <h2 className="text-2xl font-bebas mb-4">About Me</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {contentSections.about.map(item => (
                  <ContentCard key={item.id} item={item} />
                ))}
              </div>
            </section>
            
            <section id="projects-section" ref={projectsRef} className="py-8">
              <h2 className="text-2xl font-bebas mb-4">Projects</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {contentSections.projects.map(item => (
                  <ContentCard key={item.id} item={item} />
                ))}
              </div>
            </section>
            
            <section id="skills-section" ref={skillsRef} className="py-8">
              <h2 className="text-2xl font-bebas mb-4">Skills</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {contentSections.skills.map(item => (
                  <ContentCard key={item.id} item={item} />
                ))}
              </div>
            </section>

            <section id="contact-section" ref={contactRef} className="py-8">
              <h2 className="text-2xl font-bebas mb-4">Contact</h2>
              <div className="bg-netflix-gray/20 p-6 rounded-lg max-w-2xl">
                <p className="text-lg mb-4">Get in touch with me for collaborations or opportunities.</p>
                <p className="text-netflix-lightgray">email@example.com</p>
                <div className="flex space-x-4 mt-4">
                  <a href="#" className="hover:text-netflix-red">LinkedIn</a>
                  <a href="#" className="hover:text-netflix-red">GitHub</a>
                  <a href="#" className="hover:text-netflix-red">Twitter</a>
                </div>
              </div>
            </section>
          </main>

          <footer className="bg-netflix-black text-netflix-lightgray py-8 px-4 border-t border-netflix-gray/30">
            <div className="container mx-auto">
              <div className="flex flex-col md:flex-row justify-between">
                <div className="mb-6 md:mb-0">
                  <NetflixLogo className="text-2xl mb-3" />
                  <p>© {new Date().getFullYear()} All Rights Reserved</p>
                </div>
                <div>
                  <h3 className="font-medium text-white mb-3">Contact</h3>
                  <p>email@example.com</p>
                  <div className="flex space-x-4 mt-4">
                    <a href="#" className="hover:text-netflix-red">LinkedIn</a>
                    <a href="#" className="hover:text-netflix-red">GitHub</a>
                    <a href="#" className="hover:text-netflix-red">Twitter</a>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ContentScreen;
