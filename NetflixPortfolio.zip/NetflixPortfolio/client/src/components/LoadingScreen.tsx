import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import NetflixLogo from "./NetflixLogo";

interface LoadingScreenProps {
  onLoadingComplete: () => void;
}

const LoadingScreen = ({ onLoadingComplete }: LoadingScreenProps) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      setTimeout(() => {
        onLoadingComplete();
      }, 500);
    }, 2500);

    return () => clearTimeout(timer);
  }, [onLoadingComplete]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 bg-netflix-black flex flex-col justify-center items-center z-50"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="mb-12">
            <NetflixLogo className="text-6xl md:text-8xl" />
          </div>
          <div className="netflix-loader flex h-12">
            <div className="h-full"></div>
            <div className="h-full"></div>
            <div className="h-full"></div>
            <div className="h-full"></div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoadingScreen;
