import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import fs from "fs";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for profiles and content items
  app.get("/api/profiles", async (req, res) => {
    try {
      const profiles = await storage.getProfiles();
      res.json(profiles);
    } catch (error) {
      res.status(500).json({ message: "Error fetching profiles" });
    }
  });

  app.get("/api/content", async (req, res) => {
    try {
      const section = req.query.section as string;
      const contentItems = section
        ? await storage.getContentItemsBySection(section)
        : await storage.getAllContentItems();
      res.json(contentItems);
    } catch (error) {
      res.status(500).json({ message: "Error fetching content items" });
    }
  });

  // Route to update profile image
  app.put("/api/profiles/:id/image", express.json(), async (req, res) => {
    try {
      const { id } = req.params;
      const { imageUrl } = req.body;
      
      if (!imageUrl) {
        return res.status(400).json({ message: "Image URL is required" });
      }
      
      const updatedProfile = await storage.updateProfileImage(parseInt(id), imageUrl);
      res.json(updatedProfile);
    } catch (error) {
      res.status(500).json({ message: "Error updating profile image" });
    }
  });

  // Route to update content item image
  app.put("/api/content/:id/image", express.json(), async (req, res) => {
    try {
      const { id } = req.params;
      const { imageUrl } = req.body;
      
      if (!imageUrl) {
        return res.status(400).json({ message: "Image URL is required" });
      }
      
      const updatedContentItem = await storage.updateContentItemImage(parseInt(id), imageUrl);
      res.json(updatedContentItem);
    } catch (error) {
      res.status(500).json({ message: "Error updating content item image" });
    }
  });
  
  const httpServer = createServer(app);

  return httpServer;
}
