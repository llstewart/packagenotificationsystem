import { 
  users, type User, type InsertUser,
  profiles, type Profile, type InsertProfile,
  contentItems, type ContentItem, type InsertContentItem,
  } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Profile methods
  getProfiles(): Promise<Profile[]>;
  getProfile(id: number): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfileImage(id: number, imageUrl: string): Promise<Profile>;
  
  // Content item methods
  getAllContentItems(): Promise<ContentItem[]>;
  getContentItemsBySection(section: string): Promise<ContentItem[]>;
  getContentItem(id: number): Promise<ContentItem | undefined>;
  createContentItem(contentItem: InsertContentItem): Promise<ContentItem>;
  updateContentItemImage(id: number, imageUrl: string): Promise<ContentItem>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private profiles: Map<number, Profile>;
  private contentItems: Map<number, ContentItem>;
  private userCurrentId: number;
  private profileCurrentId: number;
  private contentItemCurrentId: number;

  constructor() {
    this.users = new Map();
    this.profiles = new Map();
    this.contentItems = new Map();
    this.userCurrentId = 1;
    this.profileCurrentId = 1;
    this.contentItemCurrentId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }
  
  private initializeData() {
    // Add sample profiles
    const sampleProfiles = [
      {
        name: "About Me",
        imageUrl: "https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        section: "about",
      },
      {
        name: "Projects",
        imageUrl: "https://images.unsplash.com/photo-1522252234503-e356532cafd5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        section: "projects",
      },
      {
        name: "Skills",
        imageUrl: "https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        section: "skills",
      },
      {
        name: "Contact",
        imageUrl: "https://images.unsplash.com/photo-1543269664-76bc3997d9ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        section: "contact",
      },
    ];
    
    sampleProfiles.forEach(profile => {
      this.createProfile(profile);
    });
    
    // Add sample content items
    const sampleContent = {
      about: [
        {
          title: "Work Experience",
          description: "My professional journey",
          imageUrl: "https://images.unsplash.com/photo-1516110833967-0b5716ca1387?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
          section: "about"
        },
        {
          title: "Education",
          description: "My academic background",
          imageUrl: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
          section: "about"
        },
      ],
      projects: [
        {
          title: "Web Development",
          description: "Frontend & backend projects",
          imageUrl: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
          section: "projects"
        },
        {
          title: "Mobile Apps",
          description: "iOS & Android development",
          imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
          section: "projects"
        },
        {
          title: "Design Work",
          description: "UI/UX and graphic design",
          imageUrl: "https://images.unsplash.com/photo-1558655146-364adaf1fcc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
          section: "projects"
        },
      ],
      skills: [
        {
          title: "Technical Skills",
          description: "Programming languages & tools",
          imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=337&q=80",
          section: "skills"
        },
      ]
    };
    
    // Flatten and add all content items
    Object.values(sampleContent).flat().forEach(item => {
      this.createContentItem(item);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Profile methods
  async getProfiles(): Promise<Profile[]> {
    return Array.from(this.profiles.values());
  }
  
  async getProfile(id: number): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }
  
  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = this.profileCurrentId++;
    const profile: Profile = { ...insertProfile, id };
    this.profiles.set(id, profile);
    return profile;
  }
  
  async updateProfileImage(id: number, imageUrl: string): Promise<Profile> {
    const profile = await this.getProfile(id);
    if (!profile) {
      throw new Error(`Profile with ID ${id} not found`);
    }
    
    const updatedProfile: Profile = { ...profile, imageUrl };
    this.profiles.set(id, updatedProfile);
    return updatedProfile;
  }
  
  // Content item methods
  async getAllContentItems(): Promise<ContentItem[]> {
    return Array.from(this.contentItems.values());
  }
  
  async getContentItemsBySection(section: string): Promise<ContentItem[]> {
    return Array.from(this.contentItems.values()).filter(
      item => item.section === section
    );
  }
  
  async getContentItem(id: number): Promise<ContentItem | undefined> {
    return this.contentItems.get(id);
  }
  
  async createContentItem(insertContentItem: InsertContentItem): Promise<ContentItem> {
    const id = this.contentItemCurrentId++;
    const contentItem: ContentItem = { ...insertContentItem, id };
    this.contentItems.set(id, contentItem);
    return contentItem;
  }
  
  async updateContentItemImage(id: number, imageUrl: string): Promise<ContentItem> {
    const contentItem = await this.getContentItem(id);
    if (!contentItem) {
      throw new Error(`Content item with ID ${id} not found`);
    }
    
    const updatedContentItem: ContentItem = { ...contentItem, imageUrl };
    this.contentItems.set(id, updatedContentItem);
    return updatedContentItem;
  }
}

export const storage = new MemStorage();
